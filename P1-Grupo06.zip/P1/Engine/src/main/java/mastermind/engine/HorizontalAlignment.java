package mastermind.engine;

public enum HorizontalAlignment {
    NONE,
    LEFT,
    CENTRE,
    RIGHT
}
