
package vdm.mastermind.logic;

import java.util.Random;

public class Password {
    private int [] password;
    private final int min;
    private final int max;
    boolean isRepeating;
    public Password(int size,int min,int max, boolean isRepeating){
        password= new int[size];
        this.min=min;
        this.max=max;
    }

    public void generateRandom(){

        //BORRAR Y CAMBIAR

        int num = 0;
        for(int i = 0; i < password.length; ++i){
            password[i] = num;
            System.out.println(num + ", ");
            num++;
            if(num > 3) num = 0;
        }
    }

    public void generateCopy(int[] password){
        for(int i=0;i< password.length;i++){
            this.password[i]=password[i];
        }
    }

    public int[] getPassword(){
        return this.password;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public int getIntPassword( int index ) {
        return password[index];
    }
}
