package vdm.mastermind.logic;

public enum CellState {
    EMPTY,
    FILLED,
    WRONG,
    CORRECT
}