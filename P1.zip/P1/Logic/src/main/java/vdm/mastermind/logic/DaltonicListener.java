package vdm.mastermind.logic;

public interface DaltonicListener {
    void onDaltonicMode();
    void setDaltonicMode(boolean mode);
}
