package vdm.mastermind.logic.gameobjects;

import java.util.ArrayList;
import java.util.Arrays;

import vdm.mastermind.engine.interfaces.IGraphics;
import vdm.mastermind.engine.interfaces.IScene;
import vdm.mastermind.logic.Cell;
import vdm.mastermind.logic.CellState;

public final class Tracks extends GameObject{


    private int index;
    private int numMiniTracks;
    CellState state;
    public Tracks(IScene scene){
        super(scene);
    }

    public void init(int _numMiniTracks){
        this.numMiniTracks = _numMiniTracks;
        state = CellState.EMPTY;
        super.init();
    }
    public void render(IGraphics graphics){
        super.render(graphics);
        graphics.setColor(strokeColor);
        graphics.drawCircle(getX(),getY(),(getWidth()));
    }

    public void setState(CellState state) {
        this.state = state;
    }

    public CellState getState() {
        return state;
    }
}
