package vdm.mastermind.engine.interfaces.objects;

public interface IImage {

    int getWidth();
    int getHeight();
}
