package vdm.mastermind.engine.interfaces.objects;

public interface IFont {
    int getTamFont();
    boolean isBold();
    boolean isItalic();

}
