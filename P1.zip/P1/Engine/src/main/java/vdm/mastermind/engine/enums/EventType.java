package vdm.mastermind.engine.enums;

public enum EventType {
    DOWN,
    UP
}
