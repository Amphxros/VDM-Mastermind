package vdm.mastermind.engine.interfaces.objects;

public interface ISound {

    void play();
    void stop();
    void setLoop();
}
