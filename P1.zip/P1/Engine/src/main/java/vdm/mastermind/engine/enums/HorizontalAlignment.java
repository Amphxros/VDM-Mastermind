package vdm.mastermind.engine.enums;

public enum HorizontalAlignment {
    NONE,
    LEFT,
    CENTER,
    RIGHT
}
