package mastermind.engine;

import java.util.ArrayList;

public interface ISensorListener {
    void onSense();
}
