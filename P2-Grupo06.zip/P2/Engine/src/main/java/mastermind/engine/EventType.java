package mastermind.engine;

public enum EventType {
    DOWN,
    UP,
    MOVE //scroll
}
