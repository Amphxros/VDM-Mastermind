package mastermind.engine;

public interface IShareContentManager {
    void share();
}
