package mastermind.androidengine;

import android.content.Context;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import mastermind.engine.IFileManager;
import mastermind.engine.IJsonObject;

public class AndroidFileManager implements IFileManager {
    private Context context;
    public AndroidFileManager(Context context){
        this.context=context;
    }

    // the method calls a c++ function that converts a string to a SHA256 key
    // will be called with a string containing the WHOLE savefile
    static{ System.loadLibrary("native-sha-lib"); }
    public static native String Hash(String data);

    @Override
    public String generateSHA(String data) {
        return Hash(data);
    }


    @Override
    public InputStream openInputFile(String path) throws FileNotFoundException, IOException {
        return context.openFileInput(path);
    }

    @Override
    public OutputStream openOutputFile(String path) {
        try {
            return context.openFileOutput(path, Context.MODE_PRIVATE);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String readFile(String path) {
        StringBuilder result = new StringBuilder();

        try (InputStreamReader is = new InputStreamReader(context.getAssets().open(path))) {
            BufferedReader buffer = new BufferedReader(is);
            do {
                result.append(buffer.readLine());
                result.append('\n');
            } while (buffer.ready());

            is.close();
            return result.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result.toString();
    }

    @Override
    public IJsonObject readJSON(String path) {
        try {
            return new AndroidJSONObject(readFile(path));
        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public String [] getFileListDirectory(String path) {
        try {
            return context.getAssets().list(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
