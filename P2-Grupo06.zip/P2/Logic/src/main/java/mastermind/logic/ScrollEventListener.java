package mastermind.logic;

public interface ScrollEventListener {
    void onScroll(int deltaY);
}
