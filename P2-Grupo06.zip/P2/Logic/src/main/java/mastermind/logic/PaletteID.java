package mastermind.logic;

public enum PaletteID {
    Default,
    Cinema,
    CrabOnSnow,
    TokyoCity,
    CherryBubble,
    CelesteMountain,
    NumPalettes
}
