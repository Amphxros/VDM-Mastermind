package mastermind.logic;

public enum CellState {
    Empty,
    Filled,
    Correct,
    Misplaced
}
