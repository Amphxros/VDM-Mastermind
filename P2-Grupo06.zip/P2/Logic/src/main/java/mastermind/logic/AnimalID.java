package mastermind.logic;

public enum AnimalID {
    None, //circles
    fish,
    capybara,
    bird,
    frog,
    cat,
    armadillo,



    Num_Animals
}
