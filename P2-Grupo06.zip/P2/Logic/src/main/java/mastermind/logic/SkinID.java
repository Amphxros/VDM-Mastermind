package mastermind.logic;

public enum SkinID {
    basic,
    fruity,
    halloween,
    xmas
}
